
def validate_email(email):
    return '@' in email

def validate_age(age):
    return age > 0 and age < 120

def validate_date(date):
    import datetime
    try:
        datetime.datetime.strptime(date, "%Y-%m-%d")
        return True
    except ValueError:
        return False
