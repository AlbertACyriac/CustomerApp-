
import unittest
from validation import *

class TestValidation(unittest.TestCase):
    def test_validate_email(self):
        self.assertTrue(validate_email("test@example.com"))
        self.assertFalse(validate_email("invalid.com"))

    def test_validate_age(self):
        self.assertTrue(validate_age(25))
        self.assertFalse(validate_age(-5))

    def test_validate_date(self):
        self.assertTrue(validate_date("2023-01-01"))
        self.assertFalse(validate_date("01-01-2023"))

if __name__ == "__main__":
    unittest.main()
