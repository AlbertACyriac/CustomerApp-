
customers = []

def load_sample_data():
    global customers
    customers = [
        {"id": 1, "name": "Alice", "email": "alice@example.com", "age": 30, "join_date": "2023-01-01"},
        {"id": 2, "name": "Bob", "email": "bob@example.com", "age": 25, "join_date": "2023-01-02"},
        # Add 8 more customer entries
    ]
    print("Sample data loaded.")

def view_customers():
    for cust in customers:
        print(f"{cust['id']} - {cust['name']}")

def add_customer():
    name = input("Enter name: ")
    email = input("Enter email: ")
    age = int(input("Enter age: "))
    join_date = input("Enter join date (YYYY-MM-DD): ")
    new_id = len(customers) + 1
    customers.append({"id": new_id, "name": name, "email": email, "age": age, "join_date": join_date})
    print("Customer added successfully.")

def update_customer():
    cust_id = int(input("Enter customer ID to update: "))
    for cust in customers:
        if cust['id'] == cust_id:
            cust['name'] = input("Enter new name: ")
            cust['email'] = input("Enter new email: ")
            cust['age'] = int(input("Enter new age: "))
            cust['join_date'] = input("Enter new join date (YYYY-MM-DD): ")
            print("Customer updated successfully.")
            return
    print("Customer not found.")

def delete_customer():
    cust_id = int(input("Enter customer ID to delete: "))
    global customers
    customers = [cust for cust in customers if cust['id'] != cust_id]
    print("Customer deleted successfully.")

def view_customer_details():
    cust_id = int(input("Enter customer ID: "))
    for cust in customers:
        if cust['id'] == cust_id:
            print(cust)
            return
    print("Customer not found.")
