
from customer_ops import *
from validation import *

def main_menu():
    while True:
        print("\n--- Customer Management System ---")
        print("1. View All Customers")
        print("2. Add Customer")
        print("3. Update Customer")
        print("4. Delete Customer")
        print("5. View Customer Details")
        print("6. Exit")

        choice = input("Enter your choice: ")
        if choice == '1':
            view_customers()
        elif choice == '2':
            add_customer()
        elif choice == '3':
            update_customer()
        elif choice == '4':
            delete_customer()
        elif choice == '5':
            view_customer_details()
        elif choice == '6':
            print("Exiting application...")
            break
        else:
            print("Invalid option. Try again.")

if __name__ == "__main__":
    load_sample_data()
    main_menu()
